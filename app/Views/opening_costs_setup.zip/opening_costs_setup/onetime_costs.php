                    <div class="tab-content">
                      
                      <!-- ===============================================-->
                          <!--   Wizard Tab 1  Content Details-->
                      <!-- ===============================================-->      

                      <div class="tab-pane active " role="tabpanel" aria-labelledby="bootstrap-wizard-tab1" id="bootstrap-wizard-tab1">
                          <form novalidate="novalidate">

                              <!--<p class="mt-2 text-primary">                         
                                  Make a list of al your office equipment that your will need to operate your company                                      
                              </p>  -->

                              <div class="card mb-1 mb-lg-0">
                                  <div class="card-header">
                                    <h5 class="mb-0">One-Time Costs </h5>
                                  </div>
                        
                                      <div class="card-body bg-light">
                                        <a class="mb-3 d-block d-flex align-items-center" id="one_time-form_toogle" style='cursor: pointer;'>
                                        <span class="circle-dashed"><span class="fas fa-plus"></span></span><span class="ms-3">Add new item</span></a>
                                     

                                            <div class="collapse one_time-form_collapse" id="one_time-form">

                                          <div class="container handlecurrencyformat" >
                                              <div class="form-floating mb-3">
                                                  <select name="one_time_cost_cat" class="form-select validate" id="one_time_cost_cat" aria-label="oneTimeCost">
                                                  <option value=''>Select Category</option>
                                                  <!--<option value="Land_Buildings">Land & Buildings</option>
                                                  <option value="Plant_Equipment">Plant & Equipment(Computers,Office Furniture)</option>-->
                                                  <option value="Security_Deposit">Security Deposit(Rental Bond,Telephone Security Bond)</option>
                                                  <option value="One_Time_Costs">One-Time Cost (Business Registration, Office Stationary)</option>
                                                  <option value="Interlectual_Property">Intellectual_Property (Patents,Special Licenses)</option>
                                                  </select><!-- ./select -->
                                              </div><!-- ./form floating-->
                                      
                                              <div id="general">
                                                  <div class="row">
                                                  <div class="col-6">
                                                      <div class="form-floating mb-2">
                                                      <input type="text" name="one_time_cost_description" class="form-control validate" id="one_time_cost_description" placeholder="Describe this One-Time Cost?" value="">
                                                      <label for="one_time_cost_description">Describe this item</label>
                                                      </div><!-- ./from floating -->
                                                  </div><!-- ./col -->
                                                  
                                                  <div class="col-6">
                                                      <div class="form-floating mb-2">
                                                      <input type="text" name="amount_paid" class="form-control currencySign validate" id="amount_paid" placeholder="Amount" value="<?php echo $currency; ?>">
                                                      <label for="amount_paid">What is the cost of this item?</label>
                                                      </div><!-- ./from floating -->
                                                  </div><!-- ./col -->
                                                  </div><!-- ./row -->
                                              </div><!-- ./general -->
                                          </div><!-- ./container -->
                                          <div class="border-dashed-bottom my-3"></div>
                                              <div class="col-12 col-sm-12 offset-0 pt-3">
                                                  <input type='hidden' id='openingcost_id' value='0'>
                                                  <button class="btn btn-falcon-danger" type="button" id="btncancelonetimecost" ><i class="far fa-window-close"></i> Cancel</button>
                                                  <button class="btn btn-falcon-success float-end" type="button" id="btnsaveonetimecost">Save</button>
                                              </div>
                                          </div>                         
                                      </div>
                                  </div>

                                  <div class="box-body pt-3">
                                      <div class="box-body table_one">
                                          <div class="row" id="one_time_cost_row_add">
                                
                                                  <div class="col-lg-12 col-md-12 col-sm-12" id="one_time_cost" style='margin-top: 16px;'>
                                                      <div id="tableExample2" data-list='{"page":1,"pagination":true}'>
                                                          <div class="table-responsive scrollbar">
                                                              <div class="fixTableHead">
                                                                <table id="onetimecostsDT" class="table table-striped fs--1 mb-0" style="width:100%">
                                                                    <thead class="bg-200 text-900">
                                                                        <tr>
                                                                        <th>One Time Cost</th>
                                                                        <th>Description</th>
                                                                        <th>Amount Paid</th>
                                                                        <th>Total Cost</th>
                                                                        <th>Action</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                    </tbody>
                                                                    <tfoot>
                                                                    <tr>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                    </tr>
                                                                </tfoot>
                                                            </table>                      
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>      
                                </div>
                
                
                        </form>
                    </div>