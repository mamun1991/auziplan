
<!-- ===============================================-->
<!--   Wizard Tab 3  Content Details-->
<!-- ===============================================-->      

<div class="tab-pane " role="tabpanel" aria-labelledby="bootstrap-wizard-tab7" id="bootstrap-wizard-tab7">
    <form class="form-validation">

        <!--<p class="mt-2 text-primary">                                 
            If your planing on buying a warehouse or office space yoy can evaluate the cost and depreciation.           
        </p>  -->
        <div class="card mb-1 mb-lg-0">
            <div class="card-header">
                <h5 class="mb-0">Business Summary</h5>
            </div><!-- ./card header -->
        <div class="card-body bg-light">


        <table id="" class="table fs--1 mb-0 table-responsive" cellspacing="0" width="100%">
                                <thead class="bg-200 text-900">
                                    <tr>
                                        <th colspan='2'>Business Funding</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td width='100%'>Directors Capital Investment</td>
                                            <td><?php
                                                $user_id = $this->session->userdata('user')->id;
                                                $this->db->from('director');
                                                $this->db->where('user_id', $user_id);
                                                $query = $this->db->get();
                                                $dir = $query->result();
                                                $dir_total = 0;

                                                foreach ($dir as $d) {
                                                    $dir_total = $dir_total + $d->amount;
                                                }
                                                echo $cur . ' ' . number_format($dir_total, 2, '.', ',');
                                                ?>
                                            </td>
                                    </tr>
                                    <tr>
                                        <td width='100%'>Investor Capital Investment</td>
                                        <td><?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $this->db->from('investor');
                                            $this->db->where('user_id', $user_id);
                                            $query = $this->db->get();
                                            $inv = $query->result();
                                            $inv_total = 0;

                                            foreach ($inv as $i) {
                                                $inv_total = $inv_total + $i->amount;
                                            }
                                            echo $cur . ' ' . number_format($inv_total, 2, '.', ',');
                                            ?></td>
                                    </tr>
                                    <tr>
                                        <td width='100%'>Issued Shares</td>
                                        <td><?php
                                            //Bailey here we need to fetch the issued shares value
                                            $user_id = $this->session->userdata('user')->id;
                                            $query = $this->db->query('select *from issues_table WHERE user_id="' . $user_id . '"');
                                            $row = $query->row();
                                            if ($query->num_rows() >= 1) {
                                                $issued_shares = (int) $row->issues_shared_1;
                                                $price = (int) $row->price_share2_1;
                                                $capitalisation = $issued_shares * $price;
                                            } else {
                                                $capitalisation = 0;
                                            }

                                            echo $cur . ' ' . number_format($capitalisation, 2, '.', ',');

                                            //$var = $this->session->userdata;
                                            //$sql = mysql_query("select * from bankloan where user_id='".$var['user'->id."'");
                                            //$row = mysql_fetch_array($sql);
                                            //foreach($data['everydata'] as $la){
                                            //  $la_total = $la_total + $la['loan_amount'];
                                            //}
                                            //if($la_total){
                                            //echo $cur . ' ' . number_format($data['everydata'][0]['loan_amount'], 2, '.', ',');
                                            //}
                                            //print_r('<pre>');
                                            //print_r($data['everydata'][0]['loan_amount']);
                                            //print_r('</pre>');
                                            //exit;
                                            ?></td>
                                    </tr>
                                    <tr>
                                        <td width='80%'>Loan Amount</td>
                                        <td><?php
                                            //$var = $this->session->userdata;
                                            //$sql = mysql_query("select * from bankloan where user_id='".$var['user'->id."'");
                                            //$row = mysql_fetch_array($sql);
                                            //foreach($data['everydata'] as $la){
                                            //  $la_total = $la_total + $la['loan_amount'];
                                            //}
                                            //if($la_total){
                                            echo $cur . ' ' . number_format($data['everydata'][0]['loan_amount'], 2, '.', ',');
                                            //}
                                            //print_r('<pre>');
                                            //print_r($data['everydata'][0]['loan_amount']);
                                            //print_r('</pre>');
                                            //exit;
                                            ?></td>
                                    </tr>

                                    <tr style="background-color: rgba(13, 110, 253, 0.10);">
                                        <th width='100%'style="text-align:left">Total cash raised to start the business</th>
                                        <th><?php echo $cur . ' ' . number_format(((int) $data['everydata'][0]['loan_amount'] + (int) $capitalisation + (int) $dir_total + (int) $inv_total), 2, '.', ','); ?></th>
                                    </tr>
                                    <thead class="bg-200 text-900">
                                        <tr>
                                            <th colspan='2'>Startup Expenses</th>
                                        </tr>
                                    </thead>
                                    <tr>
                                        <td width='100%'>Land & Buildings</td>
                                        <td><?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $this->db->from('one_time_cost');
                                            $this->db->where('user_id', $user_id);
                                            $this->db->where('one_time_cost', 'Land_Buildings');
                                            $query = $this->db->get();
                                            $Land = $query->result();
                                            foreach ($Land as $la) {
                                                $la_total = $la_total + $la->amount_paid;
                                            }
                                            if ($la_total) {
                                                echo $cur . ' ' . number_format($la_total, 2, '.', ',');
                                            }
                                            ?></td>
                                    </tr>
                                    <tr>
                                        <td width='100%'>Plant & Equipment</td>
                                        <td><?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $this->db->from('one_time_cost');
                                            $this->db->where('user_id', $user_id);
                                            $this->db->where('one_time_cost', 'Plant_Equipment');
                                            $query = $this->db->get();
                                            $Land = $query->result();
                                            foreach ($Land as $la) {
                                                $pe_total = $pe_total + $la->total_cost;
                                            }
                                            if ($pe_total) {
                                                echo $cur . ' ' . number_format($pe_total, 2, '.', ',');
                                            }
                                            ?></td>
                                    </tr>
                                    <tr>
                                        <td width='100%'>Security Deposit(s)</td>
                                        <td><?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $this->db->from('one_time_cost');
                                            $this->db->where('user_id', $user_id);
                                            $this->db->where('one_time_cost', 'Security_Deposit');
                                            $query = $this->db->get();
                                            $Land = $query->result();
                                            foreach ($Land as $sd) {
                                                $sd_total = $sd_total + $sd->total_cost;
                                            }
                                            if ($sd_total) {
                                                echo $cur . ' ' . number_format($sd_total, 2, '.', ',');
                                            }
                                            ?></td>
                                    </tr>
                                    <tr>
                                        <td width='100%'>Intellectual Property</td>
                                        <td><?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $this->db->from('one_time_cost');
                                            $this->db->where('user_id', $user_id);
                                            $this->db->where('one_time_cost', 'Interlectual_Property');
                                            $query = $this->db->get();
                                            $Land = $query->result();
                                            foreach ($Land as $ip) {
                                                $ip_total = $ip_total + $ip->total_cost;
                                            }
                                            if ($sd_total) {
                                                echo $cur . ' ' . number_format($ip_total, 2, '.', ',');
                                            }
                                            ?></td>
                                    </tr>
                                    <tr>
                                        <td width='100%'>One -Time Costs</td>
                                        <td><?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $this->db->from('one_time_cost');
                                            $this->db->where('user_id', $user_id);
                                            $this->db->where('one_time_cost', 'ONE_TIME_COSTS');
                                            $query = $this->db->get();
                                            $Land = $query->result();

                                            foreach ($Land as $ot) {
                                                $ot_total = $ot_total + $ot->total_cost;
                                            }
                                            if ($ot_total) {
                                                echo $cur . ' ' . number_format($ot_total, 2, '.', ',');
                                            }
                                            ?></td>
                                    </tr>
                                    <tr style="background-color: rgba(13, 110, 253, 0.10);">
                                        <th width='100%' style="text-align:left">Total cash spent on start up expenses before the start of trading</th>
                                        <th><?php echo $cur . ' ' . number_format($la_total + $pe_total + $sd_total + $ip_total + $ot_total, 2, '.', ','); ?></th>
                                    </tr>

                                    <!--------------------------------------------------------------------
                                    29TH May We need to review this calculation as we should be dividing the amount by
                                    the gst
                                    ---------------------------------------------------------------------->

                                    <!--<tr>
                                    <td width='80%'>VAT/GST Component</td>
                                        <td><?php
                                        //$this->load->model('Company_setup_model');
                                        //$company_detail = $this->Company_setup_model->get_company_detail();
                                        //$query = $this->db->query('select company_vat_collected from general_assumption where user_id="' . $user_id . '" AND company_id="' .$company_detail['id'] . '"');
                                        //$company_vat_collected = $query->row()->company_vat_collected;
                                        //$vatgst_component = ($la_total + $pe_total + $sd_total + $ot_total ) * $company_vat_collected /100;
                                        // $company_vat); // change by kuldip ladola
                                        //echo $cur . ' ' . number_format($vatgst_component, 2, '.', ',');
                                        ?></td>
                                    </tr>-->
                                    <thead class="bg-200 text-900">
                                        <tr>
                                            <th colspan='2'>Operating Expenses</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    $user_id = $this->session->userdata('user')->id;
                                    $this->db->from('expenses');
                                    $this->db->group_by('purpose');
                                    $this->db->where('user_id', $user_id);
                                    $query = $this->db->get();
                                    $dir = $query->result();
                                    ?>
                                    <?php foreach ($dir as $e) { ?>
                                        <tr>
                                            <?php
                                            $user_id = $this->session->userdata('user')->id;
                                            $query = $this->db->query("SELECT sum(weekly_cost) as weekly_total_cost, sum(num_month) as num_month FROM expenses WHERE user_id=$user_id AND purpose='$e->purpose' GROUP BY purpose");

                                            $result = $query->row();
                                            ?>
                                            <td width='100%'><?php echo $e->purpose; ?></td>
                                            <?php $tot_month = ($result->num_month == 0) ? $result->weekly_total_cost : ($result->weekly_total_cost * 52 / 12) * $result->num_month; ?>
                                            <td><?php echo $cur . ' ' . number_format($tot_month, 2, '.', ','); ?></td>
                                            <?php $total_month += $tot_month; ?>
                                        <?php } ?>
                                        <tr style="background-color: rgba(13, 110, 253, 0.10);">
                                            <th width='100%'style="text-align:left">Total projected recurring costs for at least 6 months</th>
                                            <th><?php echo $cur . ' ' . number_format($total_month, 2, '.', ','); ?></th>
                                        </tr>


                                        <thead class="bg-200 text-900">
                                            <tr>
                                                <th colspan='2'>Cash Requirement</th>
                                            </tr>
                                        </thead>


                                        <tr>
                                            <th width='100%' style="text-align:left">Total cash required to start the business</th>
                                            <th><?php
                                                //echo $cur.' '.number_format($dir_total + $mb_total + $la_total + $pe_total + $sd_total + $ot_total,2,'.',',');
                                                //$total_capital_required = $vatgst_component + $la_total + $pe_total + $sd_total + $ot_total + $total_month;

                                                $total_capital_required = $la_total + $pe_total + $ip_total + $sd_total + $ot_total + $total_month;

                                                echo $cur . ' ' . number_format($total_capital_required, 2, '.', ',');
                                                ?></th>
                                        </tr>

                                        <!--<tr style="background-color:#E3EEF5">
                                        <th width='80%'>Total cash available  in the bank account at start of trading</th>
                                        <th id='table_surplus'><?php
                                            echo $cur . ' ' . number_format(((int) $data['everydata'][0]['loan_amount'] + (int) $capitalisation + (int) $dir_total + (int) $inv_total) -
                                            ($la_total + $pe_total + $sd_total + $ot_total + $vatgst_component), 2, '.', ',');
                                        ?></th>
                                        </tr>-->

                                        <tr style="background-color: rgba(13, 110, 253, 0.10);">
                                            <th width='100%'style="text-align:left">Total cash available in the bank account at start of trading</th>
                                            <th id='table_surplus'><?php
                                                echo $cur . ' ' . number_format(((int) $data['everydata'][0]['loan_amount'] + (int) $capitalisation + (int) $dir_total + (int) $inv_total) -
                                                ($la_total + $pe_total + $ip_total + $sd_total + $ot_total), 2, '.', ',');
                                            ?></th>
                                        </tr>


                                        <tr style="background-color: rgba(13, 110, 253, 0.10);">
                                            <th width='100%'style="text-align:left">Total cash surplus or deficit after expenditure</th>
                                            <th id='table_surplus'><?php echo $cur . ' ' . number_format(((int) $data['everydata'][0]['loan_amount'] + (int) $capitalisation + (int) $dir_total + (int) $inv_total) - $total_capital_required, 2, '.', ','); ?></th>
                                        </tr>

                                </tbody>
                            </table>

            
                            <!--<table id="" class="table  fs--1 mb-0 table-responsive" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                    <th width='80%'>Total Funds Required </th>
                                    <th><?php
                                        echo $cur . ' ' . number_format($total_month, 2, '.', ',');
                                    ?></th>
                                </tr>
                            </thead>
                        </table>   -->




        </div><!-- ./card body -->

    </div><!-- ./card -->
</form><!-- ./form -->
</div><!-- ./tab pane -->
