<!-- ===============================================-->
                                <!--   Wizard Tab 2  Content Details-->
                            <!-- ===============================================-->      

                            <div class="tab-pane " role="tabpanel" aria-labelledby="bootstrap-wizard-tab3" id="bootstrap-wizard-tab3">
                                <form>
                                <!--<p class="mt-2 text-primary">                         
                                    Make a list of al your office equipment that your will need to operate your company                                      
                                </p>-->  
                                <div class="card mb-1 mb-lg-0">
                                    <div class="card-header">
                                    <h5 class="mb-0">Plant and Equipment</h5>
                                    </div>
                                    <div class="card-body bg-light">
                                        <a class="mb-3 d-block d-flex align-items-center" id="plant_equipment_toogle" style='cursor: pointer;'>
                                        <span class="circle-dashed"><span class="fas fa-plus"></span></span><span class="ms-3">Add new item</span></a>
                                        <div class="collapse" id="plant_equipment_collapse">
                                            <div id="plant_equipment">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                                            <div class="form-floating mb-3">
                                                                <input type="text" name="asset_description" class="form-control validate" id="asset_description" placeholder="Asset Description" value="">
                                                                <label for="asset_description">Asset Description</label>
                                                            </div><!-- ./from floating -->
                                                            <div class="form-floating mb-3">
                                                                <input type="text" name="aquistion_cost" class="form-control currencySign validate" id="aquistion_cost" placeholder="Asset Description" value="">
                                                                <label for="aquistion_cost">Acquisition Cost</label>
                                                        </div>
                                                        <!-- <div class="form-group">
                                                        <div class="col-md-12">
                                                            <div class="group">
                                                                <input type="text" name="gst" id="gst">
                                                                <span class="highlight"></span>
                                                                <span class="bar"></span>
                                                                <label class="group-label">GST</label>
                                                            </div>
                                                        </div>
                                                    </div> -->
                                                    <div class="form-floating mb-3">
                                                    <input type="text" name="useful_life" class="form-control validate" id="useful_life" placeholder="Useful Life(Years)" value="">
                                                    <label for="aquistion_cost">Useful Life(Years)</label>
                                                </div><!-- ./from floating -->
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="form-floating mb-3">
                                                    <input type="text" name="qty" class="form-control validate" id="plantequip_qty" placeholder="Quantity" value="">
                                                    <label for="aquistion_qty">Quantity</label>
                                                </div><!-- ./from floating -->
                                                        <!-- <div class="form-group">
                                                        <div class="col-md-12">
                                                            <div class="group">
                                                                <input type="text" name="total" id="aquistion_total" readonly>
                                                                <span class="highlight"></span>
                                                                <span class="bar"></span>
                                                                <label class="group-label">Total</label>
                                                            </div>
                                                        </div>
                                                    </div> -->
                                                    <div class="form-floating mb-3">
                                                    <select name="depreciation_method" class="form-select validate" id="depreciation_method" aria-label="oneTimeCost">
                                                        <option value="" selected>Select</option>
                                                        <option value="SL">SL(Straight Line)</option>
                                                    </select><!-- ./select -->
                                                    <label for="depreciation_method">Depreciation_Method</label>
                                                    </div><!-- ./from floating -->
                                                    <div class="form-floating mb-3">
                                                    <input type="text" name="salvage_value" class="form-control currencySign validate" id="salvage_value" placeholder="Quantity" value="">
                                                    <label for="salvage_value">Salvage Value</label>
                                                    </div><!-- ./from floating -->
                                                </div><!-- ./col -->
                                            </div><!-- ./row -->
                                        </div><!-- ./col -->
                                    </div><!-- ./pant and equipment -->     
                                                   
                                    <div class="border-dashed-bottom my-3"></div>
                                        <div class="col-12 col-sm-12 offset-0 pt-3">
                                            <input type='text' id='plantequipment_id' value=''>
                                            <button class="btn btn-falcon-danger" type="button" id="btncanceplantequipment" ><i class="far fa-window-close"></i> Cancel</button>
                                            <button class="btn btn-falcon-success float-end" id="btnsaveplantequipment" type="button">Save</button>
                                        </div>
                                    </div>                           
                                </div>
                            </div>

                            <div class="box-body pt-3">
                                <div class="box-body table_one">
                                    <div class="row" id="one_time_cost_row_add">
                                        
                                            <div class="col-lg-12 col-md-12 col-sm-12" id="one_time_cost_plant_equipment" style='margin-top: 16px;'>
                                                <div id="tableExample2" data-list='{"page":1,"pagination":true}'>
                                                    <div class="table-responsive scrollbar">
                                                        <div class="fixTableHead">
                                                        <table id="planequipmentDT" class="table table-striped fs--1 mb-0"  style="width:100%">
                                                                <thead class="bg-200 text-900">
                                                                    <tr>
                                                                    <th>Asset Description</th>
                                                                    <th>Qty</th>
                                                                    <th>Acquisition Cost</th>
                                                                    <th>Total</th>
                                                                    <th>GST</th>
                                                                    <th>Depreciation Method </th>        
                                                                    <th>Useful Life(Year)</th>
                                                                    <th>Salvage Value</th>
                                                                    <th>Monthly </th>
                                                                    <th>Year 1 </th>
                                                                    <th>Year 2 </th>
                                                                    <th>Year 3 </th>
                                                                    <th >Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                </tbody>
                                                                <tfoot>
                                                                    <tr>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                        <th></th>
                                                                    </tr>
                                                                </tfoot>
                                                        </table> 
                                                 </div>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>      
                                </div>
                            <div class="mb-3" style="display:none">
                                <label class="form-label" for="bootstrap-wizard-wizard-email">Email*</label>
                                <input class="form-control" type="email" name="email" placeholder="Email address" pattern="^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$" required="required" id="bootstrap-wizard-wizard-email" data-wizard-validate-email="true" />
                                <div class="invalid-feedback">You must add email</div>
                            </div>
            
                    </form>
                </div>
