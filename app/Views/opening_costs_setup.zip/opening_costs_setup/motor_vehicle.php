
                <!-- ===============================================-->
                <!--   Wizard Tab 3  Content Details-->
                <!-- ===============================================-->      

                <div class="tab-pane " role="tabpanel" aria-labelledby="bootstrap-wizard-tab4" id="bootstrap-wizard-tab4">
                    <form class="form-validation">














                    
                        <!--<p class="mt-2 text-primary">                                 
                            If your planing on buying a warehouse or office space yoy can evaluate the cost and depreciation.           
                        </p>  -->
                        <div class="card mb-1 mb-lg-0">
                            <div class="card-header">
                                <h5 class="mb-0">Motor Vehicle</h5>
                            </div>
                            <div class="card-body bg-light">
                                <a class="mb-3 d-block d-flex align-items-center" href="#motor_vehicle-form"  data-bs-toggle="collapse" aria-expanded="false" aria-controls="motor_vehicle-form">
                                <span class="circle-dashed"><span class="fas fa-plus"></span></span><span class="ms-3">Add Motor Vehicle</span></a>
                                <div class="collapse" id="motor_vehicle-form">

                                    <div id="motor_vehicle">
                                        <div class="col-lg-12 col-md-12 col-sm-12">


                                        <form class="form-horizontal well w3-center" >
    
                                        <div class="row">
                                                <div class="col-lg-4 col-md-4 col-sm-12">

                                                <div class="form-floating mb-3">
                                                    <input type="text" name="acquisition_date" class="form-control" id="acquisition_date" placeholder="Purchase Date" value="<?= date('m/d/Y') ?>">
                                                    <label for="acquisition_date">Purchase Date</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                    <input type="text" name="mv_description" class="form-control" id="mv_description" placeholder="MV Description" value=""></input>
                                                    <label for="mv_description">M-V Description</label>
                                                </div><!-- ./from floating -->

                                                <div class="form-floating mb-3">
                                                    <input type="text"  class="form-control" onchange="checkForZero(this)" onblur="checkForZero(this)"  value="25000" name="cprice" class="ratecalcfield"></input>
                                                    <label for="car-price">Purchase Price</label>
                                                </div>

                                                <div class="form-floating mb-3"> 
                                                    <input type="text" class="form-control" onchange="calculatePayment(this.form)" value="0" name="cdp" class="ratecalcfield"></input>
                                                    <label for="down-payment">Down Payment</label>
                                                </div>


                                            </div><!-- ./col -->


                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                         
                                
                                                <div class="form-floating mb-3"> 
                                                    <input type="text" class="form-control" onchange="calculatePayment(this.form)" value="0" name="ctv" class="ratecalcfield"></input>
                                                    <label for="trade-in">Trade-In Value</label>          
                                                </div>

                                                <div class="form-floating mb-3">         
                                                    <input type="text" class="form-control" placeholder="Automatically Calculated" name="cfinance" class="ratecalcfield"></input>
                                                    <label for="amount-financed">Amount Financed</label>
                                                </div>

                                                <div class="form-floating mb-3">  
                                                    <input type="text" class="form-control" onchange="checkForZero(this)" onblur="checkForZero(this)"  value="3.9" name="cir" class="ratecalcfield"></input>
                                                    <label for="interest-rate">Interest Rate</label>         
                                                </div>

                                                <div class="form-floating mb-3">
                                                    <input type="text" class="form-control" onchange="checkForZero(this)" onblur="checkForZero(this)"  value="60" name="cterm" class="ratecalcfield"></input>
                                                    <label for="months">Months</label>
                                                </div>


                                    
                                            </div><!-- ./col -->


                                            <div class="col-lg-4 col-md-4 col-sm-12">


                                              
                                                <div class="form-floating mb-3"> 
                                                    <input type="text" readonly class="form-control" placeholder="Your Number Of Payments Are" name="cpayments" class="ratecalcfield"></input>
                                                    <label for="total-payments">Total Payments</label>
                                                </div>

                                                <div class="form-floating mb-3"> 
                                                    <input type="text" readonly  class="form-control" placeholder="Monthly Payments" size="7" name="cpmt" class="ratecalcfield"></input>      
                                                    <label for="monthly-payment">Monthly Payment</label>                            
                                                </div>

                                                <div class="form-floating mb-3"> 
                                                    <input type="text" readonly class="form-control" placeholder="Monthly Interest" size="7" name="cint" class="ratecalcfield"></input>      
                                                    <label for="monthly-interest">Monthly Interest</label>                            
                                                </div>

                                                <div class="form-floating mb-5"> 
                                               
                                            </div><!-- ./col -->

                                        </div><!-- ./row -->

                                    </div>
                                </form>

                            </div><!-- ./col -->
                        </div> <!-- ./land and building -->                                    
                
                    <div class="col-12 col-sm-12 offset-0 pt-3">
                        <button class="btn btn-falcon-danger" type="button" id="btncancelowner" ><i class="far fa-window-close"></i> Cancel</button>
                        <button class="btn btn-falcon-success float-end px-4  me-1 mb-1" type="button"><i class="far fa-save"></i> Save and Continue</button>
                        <input type="button" class="btn btn-falcon-success float-end px-4  me-1 mb-1" onclick="cmdCalc_Click(this.form)" value="Calculate" name="cmdCalc"></input>
                   
                    </div>
                </div>                     
            </div>
        </div>

        <div class="box-body pt-3">
            <div class="box-body table_one">
                <div class="row" id="one_time_cost_row_add">
    
                        <div class="col-lg-12 col-md-12 col-sm-12" id="one_time_cost_land_buildings" style='margin-top: 16px;'>
                            <div id="tableExample2" data-list='{"page":1,"pagination":true}'>
                                <div class="table-responsive scrollbar">
                                    <div class="fixTableHead">
                                    <table id="onetimecostsDT" class="table table-striped fs--1 mb-0" style="width:100%">
                                        <thead class="bg-200 text-900">
                                            <tr>
                                            <th>Purchase Date</th>
                                            <th>MV-Description</th>
                                            <th>Purchase Price</th>
                                            <th>Down Payment</th>
                                            <th>Trade-In Value</th>
                                            <th>Amount Financed</th>
                                            <th>Interest Rate</th>
                                            <th>Months</th>
                                            <th>Total Payments</th>
                                            <th>Monthly Payment</th>
                                            <th>Year 1</th>
                                            <th>Year 2</th>
                                            <th>Year 3</th>

                                            <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>




                                        </tr>
                                    </tfoot>
                                </table>                      
                            </div>
                            </div>
                                <div class="d-flex justify-content-center mt-3 mb-2">
                                    <button class="btn btn-sm btn-falcon-default me-1" type="button" title="Previous" data-list-pagination="prev"><span class="fas fa-chevron-left"></span></button>
                                    <ul class="pagination mb-0"></ul>
                                    <button class="btn btn-sm btn-falcon-default ms-1" type="button" title="Next" data-list-pagination="next"><span class="fas fa-chevron-right"> </span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>      
            </div>
        <div class="mb-3" style="display:none">
            <label class="form-label" for="bootstrap-wizard-wizard-email">Email*</label>
            <input class="form-control" type="email" name="email" placeholder="Email address" pattern="^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$" required="required" id="bootstrap-wizard-wizard-email" data-wizard-validate-email="true" />
            <div class="invalid-feedback">You must add email</div>
        </div>

    </form>
</div>





               <!-- Script -->
               <script>		

                function checkForZero(field) {
                    if (field.value == 0 || field.value.length == 0) {
                        alert ("This field can't be 0!");
                        field.focus(); }
                    else
                    calculatePayment(field.form);
                }

                function cmdCalc_Click(form) {
                    if (form.cprice.value == 0 || form.cprice.value.length == 0) {
                        alert ("The Price field can't be 0!");
                        form.cprice.focus(); }
                    else if (form.cir.value == 0 || form.cir.value.length == 0) {
                        alert ("The Interest Rate field can't be 0!");
                        form.cir.focus(); }
                    else if (form.cterm.value == 0 || form.cterm.value.length == 0) {
                        alert ("The Term field can't be 0!");
                        form.cterm.focus(); }
                    else
                        calculatePayment(form);
                }

                function calculatePayment(form) {
                    cfinamt = form.cprice.value - form.cdp.value - form.ctv.value; 
                    cintRate = (form.cir.value/100) / 12;
                    cmonths = form.cterm.value;
                    form.cpmt.value = Math.floor((cfinamt*cintRate)/(1-Math.pow(1+cintRate,(-1*cmonths)))*100)/100;


                    form.cfinance.value = cfinamt;
                    form.cpayments.value = cmonths;
                }

            </script>		