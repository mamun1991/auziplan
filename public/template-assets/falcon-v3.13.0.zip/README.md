## Falcon, a theme by ThemeWagon team.

---

Get the figma design file here:
[https://www.figma.com/file/qkJD9wedGISuBgUw2FLand/Falcon-Distributed-(v3.12.0)](<https://www.figma.com/file/qkJD9wedGISuBgUw2FLand/Falcon-Distributed-(v3.12.0)>)
